<img src="http://www.pirobot.org/images/RBXv2Cover.png" align="left" hspace="10px">


This ROS metapackage provides sample code used in the book *ROS by Example Volume 2* [available on Lulu.com](http://www.lulu.com/shop/r-patrick-goebel/ros-by-example-volume-2-hydro/ebook/product-21735506.html).

Please use the [ROS By Example Google Group](https://groups.google.com/forum/#!forum/ros-by-example) to post questions.

The code in this branch is for **ROS Hydro**.  The accompanying book revision for ROS Hydro is available as a [downloadable PDF](http://www.lulu.com/shop/r-patrick-goebel/ros-by-example-volume-2-hydro/ebook/product-21735506.html) and [in paperback](http://www.lulu.com/shop/r-patrick-goebel/ros-by-example-volume-2-hydro/paperback/product-21774585.html).

